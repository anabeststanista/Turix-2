export const datos =[
    {
        "id":0,
        "name":"Reina",
        "img":"./img/descarga.jfif"
    },

    {
        "id":1,
        "name":"Si",
        "img":"./img/imagen1.jpg"
    },

    {
        "id":2,
        "name":"Hola",
        "img":"./img/imagen2.jpg"
    },

    {
        "id":3,
        "name":"No",
        "img":"./img/imagen3.jpg"
    },

    {
        "id":4,
        "name":"Yo",
        "img":"./img/imagen4.jpg"
    },

    {
        "id":5,
        "name":"Isa",
        "img":"./img/imagen5.jpg"
    }
]