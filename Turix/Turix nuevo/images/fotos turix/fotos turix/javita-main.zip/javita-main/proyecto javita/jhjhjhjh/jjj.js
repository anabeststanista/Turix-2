export const data =
    [
        {
            "id": 1,
            "name": "Marina",
            "img": "/img/imagen1.jpg"
        },
    

    
        {
            "id": 2,
            "name": "Taylor Swift",
            "img": "/img/imagen2.jpg"
        },

    

        {
            "id": 3,
            "name": "Marina",
            "img": "/img/imagen3.jpg"
        },

        {
            "id": 4,
            "name": "BlackPink",
            "img": "/img/imagen4.jpg"
        },

        {
            "id": 5,
            "name": "Twice",
            "img": "/img/imagen5.jpg"
        },


    ]



